For the midterm submission, our team has is deep into the project. However, not all functionality has been implemented.

To run the current implementation:
- compile the peerProcess.java, using 'javac peerProcess.java' and run that file.

Many classes are still in implementation and are not complete, such as:
- Client-server threading
- TCP handshaking
- Payload delivery via an actual message stream.

Currently, our team has accomplished connecting various peers, provided a "Common.cfg" and "PeerInfo.cfg".
More functionality is still in the works, thank you!
